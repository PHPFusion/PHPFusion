<?php
//OS:mFusionME
//version:4.01.20
//type:CORE
// User Panel
$locale['WWOLD_001'] = "Benvenuto:";
$locale['WWOLD_002'] = "Menu personale";
$locale['WWOLD_003'] = "Statistiche";
// Submit (news, link, article)
$locale['WWOLD_101'] = "Invia al sito...";
$locale['WWOLD_102'] = "Invia news";
$locale['WWOLD_103'] = "Invia link";
$locale['WWOLD_104'] = "Invia articolo";
$locale['WWOLD_105'] = "Invia photo";
$locale['WWOLD_106'] = "Invia file";
// Top 5 Download
$locale['WWOLD_201'] = "Top %s downloads";
$locale['WWOLD_202'] = "Titolo:";
// Top 5 Weblinks
$locale['WWOLD_301'] = "Top %s weblinks";
$locale['WWOLD_302'] = "Titolo:";
// Top 5 Threads
$locale['WWOLD_401'] = "Top %s threads";
$locale['WWOLD_402'] = "Titolo:";
// Top 5 Users
$locale['WWOLD_501'] = "Top %s users";
$locale['WWOLD_502'] = "Nick";
$locale['WWOLD_503'] = "Paese:";
$locale['WWOLD_504'] = "Compleanno:";
$locale['WWOLD_505'] = "Posts:";
// Top 5 News
$locale['WWOLD_601'] = "Top %s news";
$locale['WWOLD_602'] = "Titolo:";
// Top 5 articles
$locale['WWOLD_603'] = "Top %s articoli";
$locale['WWOLD_604'] = "Titolo:";
// Last posts
$locale['WWOLD_701'] = "Hai <b>%u</b> ";
$locale['WWOLD_702'] = "post<br><i>(dall'ultima visita)</i>";
$locale['WWOLD_703'] = "posts<br><i>(dall'ultima visita)</i>";
$locale['WWOLD_704'] = "Vai al Forum";
// lang adds
$locale['WWOLD_800'] = "Cambia lingua del sito";
$locale['WWOLD_801'] = "Choosen language";
// sumotoy adds
$locale['WWOLD_900'] = "Amministrazione pannello User Info";
$locale['WWOLD_901'] = "LED file [novit�]";
$locale['WWOLD_902'] = "LED file [post modificato]";
$locale['WWOLD_903'] = "LED file [entrambi]";
$locale['WWOLD_904'] = "LED file [sempre illuminato]";
$locale['WWOLD_905'] = "LED file [transparente]";
$locale['WWOLD_906'] = "LED Files [normalmente files GIF animati]";
$locale['WWOLD_907'] = "Elementi mostrati";
$locale['WWOLD_908'] = "LED";
$locale['WWOLD_909'] = "Opzioni internazionali";
$locale['WWOLD_910'] = "Tutte le lingue";
$locale['WWOLD_911'] = "Solo lingua attiva";
$locale['WWOLD_912'] = "Opzioni Downloads";
$locale['WWOLD_913'] = "Opzioni Weblinks";
$locale['WWOLD_914'] = "Opzioni News";
$locale['WWOLD_915'] = "Opzioni Forums";
$locale['WWOLD_916'] = "Opzioni Articoli";
$locale['WWOLD_917'] = "Registra settaggi";
//v2.2b6
$locale['WWOLD_918'] = "Attiva";
$locale['WWOLD_919'] = "LED file [c'� posta]";
$locale['WWOLD_920'] = "Attivazione sezioni";
$locale['WWOLD_921'] = "Opzioni Utenti";
$locale['WWOLD_922'] = "";
//v2.3b
$locale['WWOLD_930'] = "Sound WAV file [New message]";
$locale['WWOLD_931'] = "--- No sound ---";
//gauges
$locale['WWOLD_940'] = "Messages inbox:";
$locale['WWOLD_941'] = "Messages outbox:";
$locale['WWOLD_942'] = "Messages archive:";
$locale['WWOLD_943'] = "full";
?>