<?php
//OS:mFusionME
//version:4.01.20
//type:CORE
// User Panel
$locale['WWOLD_001'] = "Witaj:";
$locale['WWOLD_002'] = "W�asne menu";
$locale['WWOLD_003'] = "Statystyki strony";
// Submit (news, link, article)
$locale['WWOLD_101'] = "Napisz...";
$locale['WWOLD_102'] = "Dodaj newsa";
$locale['WWOLD_103'] = "Dodaj linka";
$locale['WWOLD_104'] = "Dodaj artyku�";
$locale['WWOLD_105'] = "Dodaj zdj�cie";
$locale['WWOLD_106'] = "Dodaj plik";
// Top 5 Download
$locale['WWOLD_201'] = "Top %s plik�w";
$locale['WWOLD_202'] = "Tytu�:";
// Top 5 Weblinks
$locale['WWOLD_301'] = "Top %s link�w";
$locale['WWOLD_302'] = "Tytu�:";
// Top 5 Threads
$locale['WWOLD_401'] = "Top %s temat�w";
$locale['WWOLD_402'] = "Tytu�:";
// Top 5 Users
$locale['WWOLD_501'] = "Top %s u�ytkownik�w";
$locale['WWOLD_502'] = "Nazwa:";
$locale['WWOLD_503'] = "Lokalizacja:";
$locale['WWOLD_504'] = "Urodziny:";
$locale['WWOLD_505'] = "Post�w:";
// Top 5 News
$locale['WWOLD_601'] = "Top %s nowo�ci";
$locale['WWOLD_602'] = "Tytu�:";
// Top 5 articles
$locale['WWOLD_603'] = "Top %s artyku��w";
$locale['WWOLD_604'] = "Tytu�:";
// Last posts
$locale['WWOLD_701'] = "Jest <b>%u</b> ";
$locale['WWOLD_702'] = "post<br><i>(od ostatniej wizyty)</i>";
$locale['WWOLD_703'] = "post�w<br><i>(od ostatniej wizyty)</i>";
$locale['WWOLD_704'] = "Przejd� do Forum";
// lang adds
$locale['WWOLD_800'] = "Zmie� j�zyk strony";
$locale['WWOLD_801'] = "Wybrany j�zyk";
// sumotoy adds
$locale['WWOLD_900'] = "User Info Panel - Administracja";
$locale['WWOLD_901'] = "Plik LED [nowe]";
$locale['WWOLD_902'] = "Plik LED [zmodyfikowane]";
$locale['WWOLD_903'] = "Plik LED [obydwa]";
$locale['WWOLD_904'] = "Plik LED [statyczny]";
$locale['WWOLD_905'] = "Plik LED [prze�roczysty]";
$locale['WWOLD_906'] = "Pliki LED [zazwyczaj pliki animowane GIF]";
$locale['WWOLD_907'] = "Liczba wy�wietlanych pozycji";
$locale['WWOLD_908'] = "Podgl�d grafiki LED";
$locale['WWOLD_909'] = "Mi�dzynarodowe opcje";
$locale['WWOLD_910'] = "Wszystkie j�zyki";
$locale['WWOLD_911'] = "Aktywny j�zyk";
$locale['WWOLD_912'] = "Opcje download";
$locale['WWOLD_913'] = "Opcje weblink�w";
$locale['WWOLD_914'] = "Opcje news�w";
$locale['WWOLD_915'] = "Opcje forum";
$locale['WWOLD_916'] = "Opcje artyku��w";
$locale['WWOLD_917'] = "Zapisz ustawienia";
//v2.2b6 - b7
$locale['WWOLD_918'] = "Aktywuj";
$locale['WWOLD_919'] = "Plik LED [Nowa wiadomo��]";
$locale['WWOLD_920'] = "Aktywacja sekcji";
$locale['WWOLD_921'] = "Opcje u�ytkownika";
$locale['WWOLD_922'] = "";
//v2.3b
$locale['WWOLD_930'] = "Plik d�wi�kowy WAV [Nowa wiadomo��]";
$locale['WWOLD_931'] = "--- Bez d�wi�ku ---";
//gauges
$locale['WWOLD_940'] = "Skrzynka odborcza:";
$locale['WWOLD_941'] = "Skrzynka nadawcza:";
$locale['WWOLD_942'] = "Skrzynka archiwum:";
$locale['WWOLD_943'] = "zape�nienia";
?>